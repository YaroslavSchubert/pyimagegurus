__author__ = 'adrianrosebrock'

# import the necessary packages
from descriptors.localbinarypatterns import LocalBinaryPatterns