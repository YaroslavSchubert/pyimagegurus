__author__ = 'adrianrosebrock'

# import the necessary packages
from resultsmontage import ResultsMontage
from hsvdescriptor import HSVDescriptor
from searcher import Searcher